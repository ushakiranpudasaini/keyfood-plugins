<?php
/**
 * Plugin Name: Timeline Elementor Widgets
 * Description: This is a custom widgets plugin for WordPress.
 * Version: 1.0
 * Author: Your Name
 * Text Domain: timeline-elementor-widget
 */

// Your plugin code goes here
if (!defined('ABSPATH')) {
    exit;
} // this is for security-no one can access plugin files directly

/**
 * Register Widgets.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_monaltimeline_custom_widgets( $widgets_manager ) {

	
	require_once( __DIR__ . '/widgets/grid-widget.php' );

	
	  $widgets_manager->register( new \Monaltimeline_Elementor_Card_Widget() );


}
add_action( 'elementor/widgets/register', 'register_monaltimeline_custom_widgets' );
