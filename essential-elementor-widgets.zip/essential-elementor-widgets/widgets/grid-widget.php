<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * grid Elementor Card Widget.
 *
 * Elementor widget that inserts card with title and description.
 *
 * @since 1.0.0
 */
class monaltimeline_Elementor_Card_Widget extends \Elementor\Widget_Base {
//Our widget code goes here

/**
	 * Get widget name.
	 *
	 * Retrieve Card widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
public function get_name() {
    return 'card';
}

/**
	 * Get widget title.
	 *
	 * Retrieve Card  widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Monal Timeline ', 'monaltimeline-elementor-widget' );
	}

    /**
	 * Get widget icon.
	 *
	 * Retrieve Card widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-header';
	}

    /**
	 * Get custom help URL.
	 *
	 * Retrieve a URL where the user can get more information about the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget help URL.
	 */
	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

    /**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the card widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'layout' ];
	}

    /**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the card widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'card', 'service', 'highlight', 'grid'];
	}

    	/**
	 * Register Card widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'monaltimeline-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
            'date',
            [
                'label' => esc_html__('Date', 'monaltimeline-elementor-widget'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '2023-01-01',
            ]
        );

        $this->add_control(
            'image_src',
            [
                'label' => esc_html__('Image Source', 'monaltimeline-elementor-widget'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://example.com/your-image.jpg',
                ],
            ]
        );
		$this->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'monaltimeline-elementor-widget'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Event description goes here.',
            ]
        );
		
		
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( ' Style', 'monaltimeline-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_options',
			[
				'label' => esc_html__( ' Title Options', 'monaltimeline-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'monaltimeline-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' =>'#f00',
				'selectors' => [
					'{{WRAPPER}} h3' => 'color: {{VALUE}};',				
				],
			]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} h3', 
				]
			);
//Description
			$this->add_control(
				'description_options',
				[
					'label' => esc_html__( ' Description Options', 'monaltimeline-elementor-widget' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
	
			$this->add_control(
				'description_color',
				[
					'label' => esc_html__( 'Color', 'monaltimeline-elementor-widget' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' =>'#f00',
					'selectors' => [
						'{{WRAPPER}} .card_description' => 'color: {{VALUE}};',				
					],
				]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'description_typography',
						'selector' => '{{WRAPPER}} .card_description', 
					]
				);
		$this->end_controls_section();

    }

	/**
	 * Render card widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */


	
		


protected function render() {
  
	$settings = $this->get_settings_for_display();

	$date = $settings['date'];
	
	$image_src = $settings['image_src']['url'];
	$description = $settings['description'];

	// Output the timeline event using the provided data
	?>
	<div class="timeline-item flex border-r ">
		<div class="timeline-date"><?php echo esc_html($date); ?></div>
		<div class="timeline-content">
		<img src="<?php echo esc_url($image_src); ?>" class="w-80 h-44 object-cover" alt="Event Image">
			<p><?php echo esc_html($description); ?></p>
		</div>
	</div>
	<?php


 

    wp_reset_postdata();
}
	
	
}